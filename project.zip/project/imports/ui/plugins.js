import Vue from 'vue'
import VueMeteorTracker from 'vue-meteor-tracker'

Vue.use(VueMeteorTracker)
import Quasar from "quasar";
Vue.use(Quasar);
import "@quasar/extras/material-icons/material-icons.css";
import "quasar/dist/quasar.min.css";
